# Placeholder for ecs-cluster module
