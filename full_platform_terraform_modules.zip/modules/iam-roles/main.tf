# Placeholder for iam-roles module
